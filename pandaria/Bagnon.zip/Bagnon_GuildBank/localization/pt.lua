--[[
	Bagnon Guild Bank Localization: Brasilian Portuguese
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bagnon-GuildBank', 'ptBR')
if not L then return end

L.Log1 = 'Registro de Transações'
L.Log3 = 'Informação da Aba'