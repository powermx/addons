Nx.GuideData["Altar Of Shadows"] = {
     ["Mode"] = 32,
     [473] = "0,58.29,70.91",
}
