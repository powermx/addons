Nx.GuideData["Alchemy Lab"] = {
	["Mode"] = 32,
}
