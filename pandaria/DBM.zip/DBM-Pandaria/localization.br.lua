﻿if GetLocale() ~= "ptBR" then return end

local L

